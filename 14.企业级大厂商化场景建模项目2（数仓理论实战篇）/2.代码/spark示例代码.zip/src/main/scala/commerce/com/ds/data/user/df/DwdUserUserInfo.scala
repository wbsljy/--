package commerce.com.ds.data.user.df

import org.apache.spark.sql.functions.{col, from_unixtime}
import org.apache.spark.sql.{DataFrame, SparkSession}

object DwdUserUserInfo {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder().enableHiveSupport().getOrCreate()
    val df = read(spark)
    val transformDF = transform(df)
    write(transformDF)
  }

  def read(spark: SparkSession): DataFrame = {
    spark.read.table("ods_commerce.ods_user_userinfo")
  }

  def transform(df: DataFrame): DataFrame = {
    df.withColumnRenamed("userid", "user_id")
      .withColumnRenamed("username", "user_name")
      .withColumn("user_money", col("usermoney").cast("decimal(20,4)"))
      .withColumn("frozen_money", col("frozenmoney").cast("decimal(20,4)"))
      .withColumnRenamed("addressid", "address_id")
      .withColumn("reg_time", from_unixtime(col("regtime").cast("bigint"), "yyyy-MM-dd HH:mm:ss"))
      .withColumn("last_login", from_unixtime(col("lastlogin").cast("bigint"), "yyyy-MM-dd HH:mm:ss"))
      .select("user_id", "user_name", "sex", "user_money", "frozen_money", "address_id", "reg_time", "last_login")
  }

  def write(df: DataFrame): Unit = {
    df.write.mode("overwrite").saveAsTable("dwd_commerce.dwd_user_userinfo_test")
  }


}
